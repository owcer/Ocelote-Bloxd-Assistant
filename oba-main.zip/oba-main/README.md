# oba
A prompt for AI models to make them a bloxd expert, especially at coding.

---
oba v1.0 is released! It can help you with coding in bloxd, as well as plenty of other things!
Here is its list of capabilities:
- Coding basic things
- Coding slightly advanced things
- Helping with general bloxd info and tips
- Giving advanced tips on coding and other things

oba stands for Ocelote Bloxd Assistant.

This is mainly a bloxd coding helper, which can help you with various scripts and codes.
All you have to is copy paste the prompt from [oba.txt](oba.txt) into your favourite AI.
I recommend you use Gemini 2.5 Pro through [Google AI Studio](https://aistudio.google.com)
